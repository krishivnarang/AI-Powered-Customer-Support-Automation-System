import sqlite3
from typing import Annotated , TypedDict
from rich.console import Console
from rich.panel import Panel
from langchain_ollama import ChatOllama
from langchain_core.messages import HumanMessage , AIMessage
from langgraph.graph import StateGraph , END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.sqlite import SqliteSaver
'''For ease of calling a variable is assigned'''
cnsl=Console() 
#     |||||||||||||(A) Simulation of RAG and Initialization|||||||||||||
llm=ChatOllama(model="qwen2.5:3b",temperature=0) 
'''Model is established with balanced temperature'''
kbdocs={"sales": "Our Pricing guide:> We offer services of Basic ($19.99/mo), Pro ($34.99/mo), and Enterprise ($129.99/mo) plans. ",
"tech": "Technical Manual:> In case the application crashes on File upload, ensure that the size of file is under 50MB and then clear your browser cache. ",
"billing": "Company Policy:> Refunds for the Annual subscription are permitted only within 30 days (1 month approx.) and also requires manual approval. ",
"account": "FAQ Document:> For resetting one's password , click on 'Forgot Password' on the login screen and then follow the email link. " }

#     |||||||||||||(B) State Definition for the overall working|||||||||||||
'''To handle messages , query tracking , categories , RAG Context , and double tier of responses'''
class SuppState(TypedDict): 
    messages: Annotated[list,add_messages]
    q: str # Current query
    cat: str # Categories -> sales , tech , billing , account , and memory are part
    needs_appr:bool # HITL (Human in the Loop) Flag pauses agent execution so human verification can occur
    ctx: str # The context for RAG
    draft: str # The department agent response required
    final_res: str # Polished response by the Supervisor

#     |||||||||||||(C) Intent and Approval Classifier |||||||||||||
def classifynode(st:SuppState)->SuppState:
    '''For classification of department and flagging of high risk queries for approval'''
    sys_prompt=f"""Analyze the customer query.
    1. Classify into EXACTLY ONE: sales, tech, billing, account, or memory (if asking about past conversation).
    2. Does it need human approval? Reply 'true' ONLY IF query involves: refund, cancellation, account closure, compensation, or escalation. Otherwise 'false'.
    
    Format: CATEGORY, BOOLEAN
    Example: billing, true
    Query: {st['q']}"""
    raw=llm.invoke(sys_prompt).content.strip().lower() #
    # Parsing the LLM's output 
    parts=[p.strip() for p in raw.split(",")]
    cat=parts[0] if len(parts)>0 and parts[0] in ["sales","tech","billing","account","memory"] else "billing"
    needs_appr=True if len(parts)>1 and "true" in parts[1] else False
    cnsl.print(f"[dim]Classifier->Dept: {cat.upper()} | Needs Approval: {needs_appr}[/dim]")
    return {"cat": cat,"needs_appr":needs_appr}

#     |||||||||||||(D) RAG Pipeline Node |||||||||||||
def ragnode(st:SuppState)->SuppState:
    '''Retreival of relevant company documents based on required categories'''
    cat=st["cat"] # category
    ctx=kbdocs.get(cat,"No specific documents found !")
    return {"ctx":ctx}

#     |||||||||||||(E) Required Specialized Agents|||||||||||||
def salesagt(st:SuppState)->SuppState:
    prmpt=f"Your job is to be a Sales Support Agent . Only Answer questions and queries based on context: {st['ctx']}\nQuery: {st['q']}"
    res=llm.invoke(prmpt).content
    return {"draft": f"[Sales Team] {res}"}
def techagt(st:SuppState)->SuppState:
    prmpt=f"Your job is to be a Technical Support Agent . Only Answer questions and queries based on context: {st['ctx']}\nQuery: {st['q']}"
    res=llm.invoke(prmpt).content
    return {"draft": f"[Tech Team] {res}"}
def blngagt(st:SuppState)->SuppState:
    prmpt=f"Your job is to be a Billing Support Agent . Only Answer questions and queries based on context: {st['ctx']}\nQuery: {st['q']}"
    res=llm.invoke(prmpt).content
    return {"draft": f"[Billing Team] {res}"}
def accntagt(st:SuppState)->SuppState:
    prmpt=f"Your job is to be a Account Support Agent . Only Answer questions and queries based on context: {st['ctx']}\nQuery: {st['q']}"
    res=llm.invoke(prmpt).content
    return {"draft": f"[Account Team] {res}"}
def mmryagt(st:SuppState)->SuppState:
    hist = "\n".join([m.content for m in st["messages"][:-1]]) # Instead of looking for RAG context , memory agent will look for messages stored in the messages state
    prmpt=f"Your job is to be a Memory Support Agent for ABC Technologies. Answer queries based on this conversation history:\n{hist}\nQuery: {st['q']}"
    res=llm.invoke(prmpt).content
    return {"draft": f"[Memory Recall] {res}"}

#     |||||||||||||(F) Supervisor Node|||||||||||||
def sprvsr_node(st:SuppState)->SuppState:
    '''Polishing the draft response into a final and professional response'''
    appr_note=" (APPROVED BY MANAGEMENT)" if st.get("needs_appr") else ""
    prmpt=f"You are the head Support Supervisor for ABC Technologies. Do not mention Alibaba Cloud. Polish this draft into a polite and professional final response to the customer: {st.get('draft','')}"
    res=llm.invoke(prmpt).content
    final_ans=res+appr_note
    return {"final_res":final_ans,"messages":[AIMessage(content=final_ans)]}

#     |||||||||||||(G) Logic for Routing|||||||||||||
def rout_agnt(st:SuppState)->str: return st.get("cat","sales")
'''Directs the flow of operations to the correct department agent'''

#     |||||||||||||(H) Building the graph|||||||||||||
bldr=StateGraph(SuppState)
bldr.add_node("classify",classifynode)
bldr.add_node("rag",ragnode)
bldr.add_node("sales", salesagt)
bldr.add_node("tech", techagt)
bldr.add_node("billing", blngagt)
bldr.add_node("account", accntagt)
bldr.add_node("memory", mmryagt)
bldr.add_node("supervisor", sprvsr_node)
bldr.set_entry_point("classify")
# Conditional edges after classification is completed
bldr.add_conditional_edges(
    "classify",
    rout_agnt,
    {   "sales": "rag",
        "tech": "rag",
        "billing": "rag",
        "account": "rag",
        "memory": "memory",  
        "general": "rag" } ) # The default case being the fallback
# Conditionally routing from RAG to the specific department agents
bldr.add_conditional_edges(
    "rag",
    rout_agnt,
    { 
        "sales": "sales",
        "tech": "tech",
        "billing": "billing",
        "account": "account",
        "general": "sales" } )
# All agents defined afterwards report to the supervisor
bldr.add_edge("sales", "supervisor")
bldr.add_edge("tech", "supervisor")
bldr.add_edge("billing", "supervisor")
bldr.add_edge("account", "supervisor")
bldr.add_edge("memory", "supervisor")
bldr.add_edge("supervisor", END)

#     |||||||||||||(I) Compilation with Memory and HITL|||||||||||||
conn = sqlite3.connect("memory.db", check_same_thread=False) # Connection with SQLite for persistence is required
mem = SqliteSaver(conn)
def hitl_check(st: SuppState) -> bool: # Interrupts before the supervisor only IF it's a high-risk request
    return st.get("needs_appr", False)
graph = bldr.compile(checkpointer=mem, interrupt_before=["supervisor"])

#     |||||||||||||(J) A demonstration run|||||||||||||
if __name__=="__main__":
    cnsl.print("\n[bold cyan]~~~ AI-Powered Cutomer Support Automation System ~~~[/bold cyan]\n")
    tst_qrys=["What are the pricing plans available for your software ?",
              "I have forgot my account password.",
              "My application crashes whenever I try to upload a file.",
              "I need a refund for my annual subscription because I changed my mind.",
              "Could you help me recall my previous support issue ?"]
    cfg={"configurable": {"thread_id": "customer_101"}} # Persistent ID for the whole loop and for all 5 queries
    for i,q in enumerate(tst_qrys,1):
        cnsl.print(f"\n[bold white]Query {i}:[/bold white] {q}")
        cnsl.print(f"\n[bold white]Query {i}:[/bold white] {q}")
        state_inp={"q": q,"messages": [HumanMessage(content=q)]} # Initial Run
        for event in graph.stream(state_inp, cfg): pass
        curr_state=graph.get_state(cfg) # Checking if graph is paused for HITL
        if len(curr_state.next)>0 and "supervisor" in curr_state.next:
            if curr_state.values.get("needs_appr"):
                cnsl.print(Panel("@@HIGH RISK DETECTED: Paused for Human Approval",border_style="red"))
                cnsl.input("[dim]Press Enter to simulate Manager Approval and Resume[/dim]")
            for event in graph.stream(None,cfg): pass
            curr_state=graph.get_state(cfg)
        final=curr_state.values.get("final_res","Error generating response")
        cnsl.print(Panel(final,title="[bold green]Final Response[/bold green]",border_style="green"))